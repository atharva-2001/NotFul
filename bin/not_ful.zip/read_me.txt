Hello!

This small python program will alert you when the battery is charging more than you want it too.
Normally, systems do not alert you when the battery is above say, more than 80 percent.
For your battery to last longer, you should keep its charge between 20 to 60 or 70 percent.

This program is made to alert you to manually remove your charger from the laptop.
From toast notifications on windows 10 to  straight up pop-ups in windows 7 devices.

INSTRUCTIONS:
1. RUN THE NOT_FUL.EXE ONCE
2. ENTER THE VALUE AT WHICH YOU WANT TO BE ALARMED AT
3. ENTER WHAT SHOULD BE THE TIME DIFFERENCE BETWEEN 2 ALARMS
4. RUN THE PROGRAM AGAIN.

(THE PROGRAM SHOULD BE RUNNING AT ALL TIMES TO FUNCTION
OR, YOU SHOULD NOT CLOSE THE CONSOLE IF YOU WANT IT TO RUN)

MAKE A DESKTOP SHORTCUT FOR QUICK ACCESS
ANYWAYS IT WILL AUTOMATICALLY START AFTER BOOTING.

If you face any issues
please contact bigpappathanos

cheers!